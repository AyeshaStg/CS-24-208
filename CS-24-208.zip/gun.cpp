#include <iostream>
using namespace std;
main()
{ 
cout<<"  +--^----------,--------,-----,--------^-,                             "<<endl;
cout<<"   | |||||||||   '--------'     |          o                            "<<endl;
cout<<"   '+---------------------------^----------|                            "<<endl;
cout<<"    ',----------,----------,-------------'                              "<<endl;
cout<<"      /  XXXXXX /'|        /'                                           "<<endl;
cout<<"     /  XXXXXX /  |       /'                                            "<<endl;
cout<<"    /  XXXXXX /'-------'                                                "<<endl;
cout<<"   /  XXXXXX /                                                          "<<endl;
cout<<"  /  XXXXXX /                                                           "<<endl;
cout<<" (---------(                                                            "<<endl;
cout<<"  '-------'                                                             "<<endl;
}


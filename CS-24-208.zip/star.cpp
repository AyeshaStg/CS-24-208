#include <iostream>
using namespace std;
main()
{
cout<<"            8888888888   888    88888            "<<endl;
cout<<"           88     88    88 88   88  88           "<<endl;
cout<<"            8888  88   88   88  88888            "<<endl;
cout<<"               88 88  888888888 88  88           "<<endl;
cout<<"        88888888  88  88     88 88   888888      "<<endl;

cout<<"        88  88  88    888    88888   888888      "<<endl;
cout<<"        88  88  88   88 88   88  88 88           "<<endl;
cout<<"        88 8888 88  88   88  88888   8888        "<<endl;
cout<<"         888  888  888888888 88  88     88       "<<endl;
cout<<"          88 88    88     88 88   8888888        "<<endl;
}